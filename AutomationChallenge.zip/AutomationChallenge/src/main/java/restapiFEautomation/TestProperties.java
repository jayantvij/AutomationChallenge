package restapiFEautomation;

import java.io.FileInputStream;
import java.util.Properties;



public class TestProperties {
	
	private static String browser;
	public final static String IE = "Internet Explorer";
	public final static String FIREFOX = "Firefox";
	public final static String CHROME = "Chrome";
	public final static String SAFARI = "Safari";
	public final static String EDGE = "Edge";
	public static String fireFoxDriverUrl;
	public static String ieDriverUrl;
	public static String chromeDriverUrl;
	public static String edgeDriverUrl;
	
	public TestProperties(String prpFileName) {

		String driversDir = System.getProperty("user.dir");
		
		fireFoxDriverUrl = driversDir + "geckodriver\\geckodriver.exe";
		ieDriverUrl = driversDir + "IEDriver\\IEDriverServer.exe";
		chromeDriverUrl = driversDir+"/chromedriver/chromedriver";
		System.out.println("chromeDriver folder Location: "+chromeDriverUrl);
		edgeDriverUrl = driversDir + "edgedriver\\MicrosoftWebDriver.exe";

			try {
	
      FileInputStream propFile = new java.io.FileInputStream(System.getProperty("user.dir")+"/src/test/resources/features/WebFE.properties");
				
				Properties p = new Properties();
		        p.load(propFile);
		     
		       
			} catch(Exception ex) {
				ex.printStackTrace();
			}
		} 

public static boolean isFirefox() {
	return FIREFOX.equals(TestProperties.getBrowser());
}


public static boolean isIE() {
	return IE.equals(TestProperties.getBrowser());
}

public static boolean isChorme() {
	return CHROME.equals(TestProperties.getBrowser());
}

public static boolean isEdge() {
	return EDGE.equals(TestProperties.getBrowser());
}


public static String getBrowser() {
	return browser;
}


public static void setBrowser(String aBrowser) {
	browser = aBrowser;
}


public static String getIeDriverUrl() {
	return ieDriverUrl;
}

public static String getChromeDriverUrl() {
	return chromeDriverUrl;
}

public static String getFireFoxDriverUrl() {
	return fireFoxDriverUrl;
}

public static String getEdgeDriverUrl() {
	return edgeDriverUrl;
}

}

