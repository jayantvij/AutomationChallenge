package restapiFEautomation;

public class Pause {

	public static void debugPause(long ms) {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e) {
		}
	}

}
