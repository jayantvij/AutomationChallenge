package restapiFEautomation;

import java.util.List;

public class AddPet {

	private String name;
	private List<String> photoUrls;
	private Category category;
	private List<Object> tags;
	private String status;


	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<String> getphotoUrls() {
		return photoUrls;
	}

	public void setphotoUrls(List<String> photoUrls) {
		this.photoUrls = photoUrls;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<Object> getTags() {
		return tags;
	}

	public void setTags(List<Object> myList1) {
		this.tags = myList1;
	}

}
