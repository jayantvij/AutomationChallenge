package tests;

import static org.junit.Assert.assertTrue;
import static org.testng.Assert.assertEquals;
import java.io.File;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import restapiFEautomation.Pause;
import restapiFEautomation.TestProperties;


public class StepDefinations {

	public static String stepName = null;
	public WebDriver driver;
	public static JavascriptExecutor jse;
	public Document xmlDoc;
	public static TestProperties tp;

	@Given("^start DemoOnlineShop webpage$")
	public void start_DemoOnlineShop_webpage() throws InterruptedException {
		stepName = "start DemoOnlineShop Webpage";
		driver = startApplication();

	}

	public WebDriver startApplication() {

		tp = new TestProperties("WebFE.properties");
		File file = new File(System.getProperty("user.dir") + "/chromedriver/chromedriver");
		System.setProperty("webdriver.chrome.driver", file.getPath());
		driver = new ChromeDriver();

		driver.manage().deleteAllCookies();

		loadLocators("webtest.locators.xmlfile");

		driver.get("https://www.demoblaze.com/index.html");
		driver.manage().window().maximize();

		return driver;
	}

	public void loadLocators(String fileName) {
		try {
			File file = new File(System.getProperty("user.dir") + "/src/main/resources/WebFELocators.xml");
			DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
			String filename = file.getAbsolutePath();

			xmlDoc = docBuilder.parse(new File(filename));
			xmlDoc.getDocumentElement().normalize();

		} catch (Exception ex) {
			System.out.println("ERROR : " + ex.getMessage());
		}
	}

	@When("^I click on '(.*)'$")
	public void I_click_on_Item(String elementName) {
		stepName = "I click on '" + elementName + "'";
		clickElement(elementName);

	}

	@When("^I enter (.*) '(.*)'$")
	public void I_enter_value(String elementName, String value) {

		stepName = "I enter " + elementName + " '" + value + "'";
		enterValue(elementName, value);
	}

	@Then("^I scroll down '(.*)'$")
	public void scrollDownPage(String size) {
		jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0," + size + ")", "");
		Pause.debugPause(2000);
	}

	@Then("^I need more time - (.*) sec$")
	public void I_need_more_time(Integer seconds) throws InterruptedException {
		Thread.sleep(seconds * 1000);
	}

	@Then("^I switch to confirm popup and Click on '(.*)' button$")
	public void ConfirmPopup(String action) {
		stepName = "I switch to confirm popup and Click on '" + action + "' button";
		confirmPopup(action);
	}

	@Then("^I verify '(.*)' is visible$")
	public void iVerifyElementIsVisible(String elementName) {
		stepName = "I verify '" + elementName + "' is visible.";
		VerifyElementIsVisible(elementName);

	}

	@Then("^I assert values '(.*)' '(.*)' '(.*)'$")
	public void iAssertValues(String elementName, String actual, String expected) {
		stepName = "I assert values '" + elementName + "' '" + actual + "' '" + expected + "' ";
		AssertValues((getElement(elementName).getText().substring(12, 27)), expected);

	}

	public void confirmPopup(String action) {
		Alert a = new WebDriverWait(driver, 10).until(ExpectedConditions.alertIsPresent());
		if (action.equalsIgnoreCase("Yes")) {
			driver.switchTo().alert().accept();
		} else if (action.equalsIgnoreCase("No")) {
			driver.switchTo().alert().dismiss();
		}
		driver.switchTo().defaultContent();
	}

	public void VerifyElementIsVisible(String elementName) {
		assertTrue("Verify element '" + elementName + "' is visible on the UI page.",
				getElement(elementName).isDisplayed());
		System.out.println("Element is visible on the page");
	}

	public void AssertValues(String actual, String expected) {
		assertEquals(actual, expected,"Verified actual purchase amount is equal to expected.");
	}

	public WebElement getElement(String elementNameOrXpath) {

		String xpath = null;
		if (elementNameOrXpath.contains("//")) {
			xpath = elementNameOrXpath;
		} else {
			xpath = getElementXpath(elementNameOrXpath);
		}

		WebElement el = null;

		boolean elementFound = false;
		boolean timedOut = false;

		if (xpath != null) {

			while (!elementFound && !timedOut) {
				try {

					List<WebElement> list = driver.findElements(By.xpath(xpath));
					for (WebElement elx : list) {
						if (elx.isDisplayed() && elx.isEnabled()) {
							elementFound = true;
							el = elx;
							// System.out.println("Element Found..!!...NEW CODE");
							break;
						}
					}
				} catch (Exception ex) {
					System.out.println("Element not found yet");
					elementFound = false;
				}

			}
		}
		return el;
	}

	public String getElementXpath(String name) {
		String xpath = null;
		try {
			NodeList node = xmlDoc.getElementsByTagName("ElementInfo");

			for (int i = 0; i < node.getLength(); i++) {
				Node oldNameNode = node.item(i).getAttributes().getNamedItem("OldName");
				String oldName = oldNameNode == null ? "" : oldNameNode.getNodeValue();
				Node newNameNode = node.item(i).getAttributes().getNamedItem("Name");
				String newName = newNameNode == null ? "" : newNameNode.getNodeValue();
				if (newName.equalsIgnoreCase(name) || oldName.equalsIgnoreCase(name)) {
					xpath = node.item(i).getTextContent();
					break;
				}
			}
			if (xpath != null && !xpath.contains("%s"))
				Assert.assertTrue("Unable to find element XPATH for '" + name + "'",
						(xpath != null) && (xpath.length() > 0));
		} catch (AssertionError e) {
			System.out.println("The error that is displayed for Assert Error: " + e.getMessage());
		}
		return xpath;
	}

	public void clickElement(String elementNameOrXpath) {
		getElement(elementNameOrXpath).click();
		Pause.debugPause(2000);
	}

	public void enterValue(String elementName, String value) {
		WebElement el = (WebElement) getElement(elementName);
		el.sendKeys(value);
		Pause.debugPause(1000);
	}

	public WebDriver getWebDriver() {
		return this.driver;
	}

	public Document getXMLDoc() {
		return this.xmlDoc;
	}

	@After
	public void closebrowser() {
		driver.close();
	}
}
