package tests;

import static io.restassured.RestAssured.given;
import java.util.List;
import org.testng.Assert;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import restapiFEautomation.ReUsableMethods;

public class GET_AvailablePets_Test {

	public static void main(String[] args) {

		RestAssured.baseURI = "https://petstore.swagger.io/v2";
		String getResponse =	given().log().all().queryParam("apiKey", "special-key").queryParam("status", "available")
				.when().get("/pet/findByStatus")
				.then().assertThat().log().all().statusCode(200).extract().response().asString();
		JsonPath js1=ReUsableMethods.rawToJson(getResponse);
		List<String> statuslist = js1.getList("status");
		System.out.println(statuslist);

		String[] statusArray = new String[statuslist.size()];
		statusArray = statuslist.toArray(statusArray);
		for (int i = 0; i < statusArray.length; i++) {
			String status = statusArray[i];
			Assert.assertEquals(status, "available");
		}
	}



}

