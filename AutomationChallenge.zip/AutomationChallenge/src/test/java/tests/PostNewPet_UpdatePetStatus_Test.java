package tests;

import static io.restassured.RestAssured.given;
import java.util.ArrayList;
import java.util.List;
import org.testng.Assert;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import restapiFEautomation.AddPet;
import restapiFEautomation.Category;
import restapiFEautomation.ReUsableMethods;
import restapiFEautomation.Tags;

public class PostNewPet_UpdatePetStatus_Test {
	public static long id;

	public static void main(String[] args) {

		RestAssured.baseURI = "https://petstore.swagger.io/v2";

		//Add new available pet to store and assert result
		AddPet p = new AddPet();
		Category c = new Category();
		c.setId(5);
		c.setName("PetAnimal");
		p.setCategory(c);
		p.setName("Elephant");
		List<String> myList = new ArrayList<String>();
		myList.add("https://currentphotourl");
		p.setphotoUrls(myList);

		Tags t = new Tags();
		t.setId(8);
		t.setName("AnimalTag");
		List<Object> myList1 = new ArrayList<Object>();
		myList1.add(t);
		p.setTags(myList1);

		p.setStatus("available");

		Response res = given().log().all().queryParam("apiKey", "special-key")
				.header("Content-Type", "application/json").body(p).when().post("/pet").then().assertThat()
				.statusCode(200).extract().response();

		String postResponse = res.asString();
		System.out.println(postResponse);

		JsonPath js1 = ReUsableMethods.rawToJson(postResponse);
		long id = js1.get("id");
		String petid = Long.toString(id);
		String name = js1.getString("name");
		String status = js1.getString("status");
		Assert.assertEquals(name, "Elephant");
		Assert.assertEquals(status, "available");

		// Update pet status to sold and assert status update
		String putResponse = given().log().all().queryParam("apiKey", "special-key")
				.header("Content-Type", "application/json")
				.body("{\r\n" + "\"id\":\"" + id + "\",\r\n" + "\"status\":\"Sold\"\r\n" + "}").when().put("/pet")
				.then().assertThat().log().all().statusCode(200).extract().response().asString();
		JsonPath js2 = ReUsableMethods.rawToJson(putResponse);
		String updatedStatus = js2.getString("status");
		Assert.assertEquals(updatedStatus, "Sold");


		// Delete pet and assert deletion
		String deleteResponse = given().log().all()
				.when().delete("/pet/"+petid+"")
				.then().assertThat().log().all().statusCode(200).extract().response().asString();
		String getResponse =	given().log().all()
				.when().get("/pet/"+petid+"")
				.then().assertThat().log().all().statusCode(404).extract().response().asString();

	}

}
